import { useEffect, useState } from "react";
import { CreditCard, FileText, Home, Settings as SettingsIcon, WalletCards } from "lucide-react";
import { AppData } from "./types/finance";
import { loadData, saveData } from "./storage/localStorage";
import { Dashboard } from "./pages/Dashboard";
import { Transactions } from "./pages/Transactions";
import { Loans } from "./pages/Loans";
import { Reports } from "./pages/Reports";
import { Settings } from "./pages/Settings";
import "./styles.css";
type Page="dashboard"|"transactions"|"loans"|"reports"|"settings";
export default function App(){ const [page,setPage]=useState<Page>("dashboard"); const [data,setData]=useState<AppData>(()=>loadData()); useEffect(()=>{ saveData(data); },[data]); const titles={dashboard:"Dashboard",transactions:"Transakcje",loans:"Kredyty i zobowiązania",reports:"Raporty miesięczne",settings:"Ustawienia"}; return <div className="app"><aside className="sidebar"><div className="brand"><div className="logo">FC</div><div><h1>Finance Control</h1><p>buduj kapitał, nie chaos</p></div></div><nav><button className={page==="dashboard"?"active":""} onClick={()=>setPage("dashboard")}><Home size={18}/> Dashboard</button><button className={page==="transactions"?"active":""} onClick={()=>setPage("transactions")}><WalletCards size={18}/> Transakcje</button><button className={page==="loans"?"active":""} onClick={()=>setPage("loans")}><CreditCard size={18}/> Kredyty</button><button className={page==="reports"?"active":""} onClick={()=>setPage("reports")}><FileText size={18}/> Raporty</button><button className={page==="settings"?"active":""} onClick={()=>setPage("settings")}><SettingsIcon size={18}/> Ustawienia</button></nav></aside><main><header className="topbar"><div><h2>{titles[page]}</h2><p>Dane są zapisywane lokalnie w tej przeglądarce.</p></div></header>{page==="dashboard"&&<Dashboard data={data}/>} {page==="transactions"&&<Transactions data={data} setData={setData}/>} {page==="loans"&&<Loans data={data} setData={setData}/>} {page==="reports"&&<Reports data={data}/>} {page==="settings"&&<Settings data={data} setData={setData}/>}</main></div>; }

