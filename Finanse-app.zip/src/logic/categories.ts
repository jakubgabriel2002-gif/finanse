import { TransactionCategory } from "../types/finance";
export const categoryLabels: Record<TransactionCategory,string> = { salary:"Wypłata", business:"Dodatkowy dochód", housing:"Mieszkanie", food:"Jedzenie", restaurants:"Jedzenie na mieście", transport:"Transport", fuel:"Paliwo", subscriptions:"Subskrypcje", entertainment:"Rozrywka", health:"Zdrowie", clothes:"Ubrania", savings:"Oszczędności", investments:"Inwestycje", emergency_fund:"Fundusz bezpieczeństwa", loan_payment:"Raty / kredyty", other:"Inne" };
export const expenseCategories: TransactionCategory[] = ["housing","food","restaurants","transport","fuel","subscriptions","entertainment","health","clothes","savings","investments","emergency_fund","loan_payment","other"];
export const incomeCategories: TransactionCategory[] = ["salary","business","other"];

