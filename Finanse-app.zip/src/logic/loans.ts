import { Loan } from "../types/finance";
export function getTotalDebt(loans: Loan[]) { return loans.filter(l=>l.status==="active").reduce((s,l)=>s+l.currentBalance,0); }
export function getMonthlyLoanPayments(loans: Loan[]) { return loans.filter(l=>l.status==="active").reduce((s,l)=>s+l.monthlyPayment,0); }
export function getDebtToIncomeRatio(monthlyIncome:number, monthlyLoanPayments:number) { if(monthlyIncome<=0) return 0; return (monthlyLoanPayments/monthlyIncome)*100; }

