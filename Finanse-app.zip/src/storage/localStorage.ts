import { AppData } from "../types/finance";
import { ensureMonthlyReport } from "../logic/reports";
const STORAGE_KEY="finance-control-data-v1";
export const defaultData: AppData = { transactions:[], loans:[], reports:[] };
export function loadData(): AppData { try { const raw=localStorage.getItem(STORAGE_KEY); if(!raw) return defaultData; const parsed=JSON.parse(raw) as AppData; const dataWithReports=ensureMonthlyReport(parsed); saveData(dataWithReports); return dataWithReports; } catch { return defaultData; } }
export function saveData(data:AppData){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
export function exportData(data:AppData){ const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}); const url=URL.createObjectURL(blob); const link=document.createElement("a"); link.href=url; link.download=`finance-control-backup-${new Date().toISOString().slice(0,10)}.json`; link.click(); URL.revokeObjectURL(url); }

