import { ChangeEvent } from "react";
import { AppData } from "../types/finance";
import { Card } from "../components/Card";
import { defaultData, exportData } from "../storage/localStorage";
type Props={data:AppData; setData:(data:AppData)=>void;};
export function Settings({data,setData}:Props){ function importJson(e:ChangeEvent<HTMLInputElement>){ const file=e.target.files?.[0]; if(!file) return; const reader=new FileReader(); reader.onload=()=>{ try{ setData(JSON.parse(String(reader.result)) as AppData); } catch { alert("Nieprawidłowy plik JSON."); } }; reader.readAsText(file); } return <div className="grid"><Card title="Kopia zapasowa"><div className="actions"><button onClick={()=>exportData(data)}>Eksportuj dane JSON</button><label className="fileButton">Importuj JSON<input type="file" accept="application/json" onChange={importJson}/></label></div></Card><Card title="Reset"><p>Reset usuwa dane lokalne z tej przeglądarki. Nie rób tego bez eksportu.</p><button className="danger" onClick={()=>{ if(confirm("Na pewno usunąć wszystkie dane?")) setData(defaultData); }}>Usuń dane</button></Card></div>; }

