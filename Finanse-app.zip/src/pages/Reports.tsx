import { AppData } from "../types/finance";
import { Card } from "../components/Card";
type Props={data:AppData};
function money(v:number){return `${v.toFixed(2)} zł`;}
export function Reports({data}:Props){ return <Card title="Raporty miesięczne">{data.reports.length===0?<p>Brak raportów. Aplikacja tworzy raport za poprzedni miesiąc automatycznie po otwarciu aplikacji.</p>:<div className="list">{data.reports.map(r=><div className="report" key={r.id}><h3>{r.month}</h3><p>Przychody: {money(r.income)}</p><p>Wydatki: {money(r.expenses)}</p><p>Kredyty / raty: {money(r.loanPayments)}</p><p>Oszczędności: {money(r.savings)}</p><p>Inwestycje: {money(r.investments)}</p><p>Fundusz bezpieczeństwa: {money(r.emergencyFund)}</p><p><strong>Saldo: {money(r.balance)}</strong></p><p>Największa kategoria wydatków: {r.topExpenseCategory}</p></div>)}</div>}</Card>; }

