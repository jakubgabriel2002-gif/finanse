export type TransactionType = "income" | "expense";
export type TransactionCategory = "salary" | "business" | "housing" | "food" | "restaurants" | "transport" | "fuel" | "subscriptions" | "entertainment" | "health" | "clothes" | "savings" | "investments" | "emergency_fund" | "loan_payment" | "other";
export type Transaction = { id:string; date:string; type:TransactionType; category:TransactionCategory; amount:number; description:string; isWasteful?:boolean; };
export type LoanType = "cash" | "mortgage" | "credit_card" | "installment" | "leasing" | "other";
export type LoanStatus = "active" | "paid_off";
export type Loan = { id:string; name:string; type:LoanType; initialAmount:number; currentBalance:number; monthlyPayment:number; interestRate:number; paymentDay:number; endDate:string; status:LoanStatus; };
export type MonthlyReport = { id:string; month:string; income:number; expenses:number; savings:number; investments:number; emergencyFund:number; loanPayments:number; balance:number; topExpenseCategory:string; createdAt:string; };
export type AppData = { transactions:Transaction[]; loans:Loan[]; reports:MonthlyReport[]; };

