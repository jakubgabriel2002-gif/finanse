# Finance Control App — Etap 1

## Funkcje
- lokalny zapis danych w przeglądarce
- dodawanie transakcji
- dashboard
- moduł kredytów / zobowiązań
- automatyczne raporty miesięczne
- eksport/import danych JSON

## Uruchomienie
```bash
npm install
npm run dev
```

Potem otwórz adres z terminala, zwykle `http://localhost:5173`.

